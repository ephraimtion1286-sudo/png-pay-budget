PNG PAY & BUDGET — ANDROID PROJECT 1.0.0

WHAT IS INCLUDED
- Android Studio project (native Android WebView app)
- Offline calculator bundled inside the app
- Automatic PNG salary tax estimate (resident / non-resident)
- NASFUND employee deduction, NCSL, other savings and deductions
- Multiple loan repayments entered as actual Kina amounts
- Take-home pay and editable budget allocation
- Payday history stored locally on the device
- JSON backup/restore and CSV export using Android's file picker
- No bank connection, account registration, analytics or remote data collection

BUILD AN APK
1. Install Android Studio on a computer.
2. Open the folder named PNGPayBudget (this folder) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio creates the debug APK under app/build/outputs/apk/debug/.
6. For a customer release, use Build > Generate Signed Bundle / APK and create/secure your own signing key. Never share your private signing key.

ANDROID REQUIREMENTS
- Application ID: com.pngpaybudget.app
- Minimum Android: Android 6.0 (API 23)
- Compile/target SDK: 35
- Internet permission is not requested. App calculations run offline.

IMPORTANT TAX NOTICE
Automatic tax uses the PNG Income Tax Act 2025 salary-and-wages tax bands. The app assumes a valid employee declaration is on file. It does not calculate dependant tax credits, taxable non-cash benefits, special allowances, irregular payments or payroll adjustments. Weekly/monthly entries convert the statutory fortnightly bands to an average equivalent for budgeting; an employer's exact withholding can differ. Compare with current IRC/employer guidance and actual payslips before relying on or selling the calculator.

PRIVACY
All payday records are kept in local app storage on this device. The app does not send salary, loan or budget information to a server. Users should protect exported backup files. Uninstalling or clearing app storage may erase saved history. See PRIVACY_POLICY.txt.

COMMERCIAL RELEASE CHECKLIST
- Verify tax calculations with PNG IRC / payroll professionals and sample payslips.
- Replace or review the publisher/support contact in the privacy policy.
- Test on multiple Android phones and Android versions.
- Create a signed release APK or AAB using your own signing key.
- Prepare Play Store screenshots, description, content rating and Data safety declarations.
- Google Play publishing requires a Play Console developer account and compliance review. This source project is not itself a Play Store listing or signed production APK.
